<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#">VHSM</a>
        <a class="navbar-brand" href="#">
            <img src="images/favicon.png" alt="" width="40" height="40">
        </a>

        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <?php
      	if(isset($_SESSION['username'])){
      ?>
                <a class="nav-link 
                    <?php if(isset($_GET['nav'])&&$_GET['nav']=='status') echo 'active"';?> 

                    href=" ?nav=status">Status</a>

                <a class="nav-link" href="logout.php">LOG OUT</a>
                <?php
        }else{     
      ?>
                <a class="nav-link <?php if(!isset($_GET['nav'])) echo "active";?>" href=" index.php">Home</span></a>
                <a class="nav-link <?php if(isset($_GET['nav'])&&$_GET['nav']=='tentang') echo "active";?> "
                    href="index.php?nav=tentang">About</span></a>
                <?php } ?>
            </div>
        </div>
    </div>
</nav>