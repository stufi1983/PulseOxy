<?php 
	include_once("../configdb.php");				
	$mysqli = $dblink;

	if(!isset($_GET['latitude'])) exit();
 	$latitude=''; if(isset($_GET['latitude'])) $latitude=$_GET['latitude'];

	if(!isset($_GET['longitude'])) exit();
 	$longitude=''; if(isset($_GET['longitude'])) $longitude=$_GET['longitude'];

	if(!isset($_GET['rssi'])) exit();
 	$rssi=''; if(isset($_GET['rssi'])) $rssi=$_GET['rssi'];

	 if(floatval($rssi)>=0) exit();
	 
	if(!is_numeric($latitude)||!is_numeric($longitude)||!is_numeric($rssi)) {exit();}
	$sql = "INSERT INTO `signalstrength` (`id`, `longitude`, `latitude`, `rssi`) 
		VALUES (NULL, ".floatval($longitude).", ".floatval($latitude).", ".floatval($rssi).");";
	 if ($result = $mysqli -> query($sql)) {
	}
	// echo $sql;
 ?>