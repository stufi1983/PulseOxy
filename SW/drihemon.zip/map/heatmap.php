<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../css/ol.css" type="text/css" />
    <style>
    .map {
        height: 800px;
        width: 800px;
    }

    .overlay-container {
        background-color: #eee;
        width: 100px;
        color: #000;
        border-radius: 3px;
        -webkit-box-shadow: 2px 2px 4px 0px rgba(0, 0, 0, 0.95);
        box-shadow: 2px 2px 4px 0px rgba(0, 0, 0, 0.95);
        padding: 2px 0;
        position: absolute;
        z-index: 1;
        margin-left: -50px;
        margin-top: 10px;
        text-align: center;
    }
    </style>
    <script src="../js/ol.js"></script>
    <title>OpenLayers example</title>
</head>

<body>
    <h2>Jangkauan Gateway</h2>
    <div id="map" class="map"></div>

    <div class="overlay-container">
        <span class="overlay-text" id="feature-name"> </span><br />
    </div>

    <script>
    window.onload = init;

    function init() {
        var map = new ol.Map({
            target: "map",
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM(),
                }),
            ],
            view: new ol.View({
                center: ol.proj.fromLonLat([109.27234654656652, -7.413721214951955]),
                zoom: 19,
                minZoom: 17,
                maxZoom: 20,
            }),
        });

        const overlayContainerElement = document.querySelector('.overlay-container');
        const overlayLayer = new ol.Overlay({
            element: overlayContainerElement
        })
        map.addOverlay(overlayLayer);
        const overlayFeatureName = document.getElementById('feature-name');


        map.on("click", function(e) {
            overlayLayer.setPosition(undefined);
            map.forEachFeatureAtPixel(e.pixel, function(feature, layer) {
                //   let clickedFeatureName = feature.get("name");
                console.log(feature.get("name"));
                overlayLayer.setPosition(e.coordinate);
                overlayFeatureName.innerHTML = feature.get("name");
            });

        });

        const lamps = new ol.layer.VectorImage({
            source: new ol.source.Vector({
                url: "./lamp.geojson",
                format: new ol.format.GeoJSON(),
            }),
            visible: true,
        });
        map.addLayer(lamps);

        //Menggunakan hetmappoint
        var db = -70;
        const heatmaplayer = new ol.layer.Heatmap({
            source: new ol.source.Vector({
                url: "getSignalPoint.php?db=" + db,
                format: new ol.format.GeoJSON(),
            }),
            blur: db * -0.8,
            radius: 20,
            // weight: function(feature) {
            //     var strength = feature.get("strength");
            //     return ((parseInt(strength) + 20) / 100) + 1;
            // }
        });
        map.addLayer(heatmaplayer);
        db = -40;
        const heatmaplayer1 = new ol.layer.Heatmap({
            source: new ol.source.Vector({
                url: "getSignalPoint.php?db=" + db,
                format: new ol.format.GeoJSON(),
            }),
            blur: db * -0.8,
            radius: 20,
            // weight: function(feature) {
            //     // var strength = feature.get("strength");
            //     // return ((parseInt(strength) + 20) / 100) + 1;
            //     return (120 + (-20)) / 120;
            // }
        });
        map.addLayer(heatmaplayer1);

    }
    </script>
</body>

</html>