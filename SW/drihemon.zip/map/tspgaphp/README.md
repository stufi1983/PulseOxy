Traveling Salesman Problem - Genetic Algorithm
----------------------------------------------

Direct PHP Conversion of the Java code found at http://www.theprojectspot.com/tutorial-post/applying-a-genetic-algorithm-to-the-travelling-salesman-problem/5

Branch 1.0 is a direct conversion with no optimization to the code.

master branch contains PHP-specific code improvements & optimization.
