<?php
$err="";
if(isset($_SESSION['loginerr']))
$err=urldecode($_SESSION['loginerr']);
if(isset($_GET['loginerr']))
$err=urldecode($_GET['loginerr']);
?>
<div class="container-lg-float homebg">
    <div class="row ">
        <div class="col-12 my-5"></div>
    </div>
    <div class="row pt-5 justify-content-evenly px-3">
        <div class="col-lg-6 my-5 text-light">
            <section class="jumbotron text-center">
                <img src="images/favicon.png" alt="Smart PJU" width="00" class="rounded-circle img-thumbnail" />
                <h1 class="display-10 mt-5">
                   VITAL HEALTH SIGN MONITORING
                </h1>
                <p class="lead pe-10 fs-5 fw-bold">
                Health monitoring systems collect vast amounts of data such as heart rate,  blood pressure, and Peripheral Oxygen Saturation rate are essential indicators of a driver’s health </p>
            </section>
        </div>
        <div class="col-lg-3 pl-10 my-5 ">
            <form class="mx-auto  bg-light p-3 shadow-sm rounded" action="ceklogin.php" method="post">
                <div class="mb-3">
                    <label for="inputUsername" class="form-label">Username</label>
                    <input name="username" type="username" class="form-control" id="inputUsername"
                        aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="inputPassword" class="form-label">Password</label>
                    <input name="password" type="password" class="form-control" id="inputPassword">
                </div>
                <div class="<?php if($err!="") echo "alert alert-danger";?>">
                    <?php if($err!="") echo $err;?>
                </div>
                <div class="mt-3 d-grid gap-2 col-6 mx-auto">
                    <button type="submit" name="login" class="btn btn-primary btn-lg btn-block">Login</button>
                </div>
            </form>
        </div>
    </div>
    <div class="row ">
        <div class="col-12 my-5"></div>
    </div>

</div>
<?php /*var_dump(headers_list());*/ ?>