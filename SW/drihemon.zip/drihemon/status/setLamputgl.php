<?php
require_once("../configdb.php");

if(!isset($_POST['lamp'])) {echo "lamp ?";exit();}

$dt="";
if(isset($_POST['dt'])){    
    $dt=$_POST['dt'];
}

if($dt!=""){
    $currentDate = new DateTime();
    //echo $currentDate->format('ymdHis');

    $sql = "INSERT INTO `setting_lampu` (`id`, `id_lampu`, `command`, `val`,`status`) VALUES (NULL, ".$_POST['lamp'].", 'D','".$currentDate->format('ymdHis')."', 'WAIT')";
    if ($dblink->query($sql) === TRUE) {
        echo "Set Date OK ";
    } else {
        echo "Error: " . $sql . "<br>" . $dblink->error;
    }
}

if(!isset($_POST['val'])) { exit();}
if($_POST['val']!=-1){
    $val = intval(abs($_POST['val'] * 255 / 100));
}
else{
    $val = 1;
}
$sql = "INSERT INTO `setting_lampu` (`id`, `id_lampu`, `command`, `val`,`status`) VALUES (NULL, ".$_POST['lamp'].", 'I','".$val."', 'WAIT')";
if ($dblink->query($sql) === TRUE) {
    echo "Set Lamp OK ";
} else {
    echo "Error: " . $sql . "<br>" . $dblink->error;
}


$dblink->close();

?>