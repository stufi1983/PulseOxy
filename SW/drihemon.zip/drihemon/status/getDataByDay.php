<?php
if(!isset($_GET['lamp']) || !isset($_GET['year'])  || !isset($_GET['month']) )
{
  echo "";
  exit();
}
include_once("../configdb.php");
//Fetch 3 rows from actor table
$result = $dblink->query("SELECT DAY( `waktu` ) as tgl, ROUND( AVG( arus ),3) as min, ROUND( MAX( arus ),3) as max FROM `status_lampu` WHERE waktu LIKE '".$_GET['year']."-".$_GET['month']."%' AND id_lampu=".$_GET['lamp']." GROUP BY DAY( `waktu` )");
  
//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);
 
?>