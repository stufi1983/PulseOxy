<?php
$lamp = 1;
if(isset($_GET['lamp']))
{
    $lamp = $_GET['lamp'];
}
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="chartjs-size-monitor">
        <div class="chartjs-size-monitor-expand">
            <div class=""></div>
        </div>
        <div class="chartjs-size-monitor-shrink">
            <div class=""></div>
        </div>
    </div>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Hourly Status of Lamp #<?=$lamp?>
        </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <!-- <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button> -->
                <form>
                    <select class="form-select" id="team" aria-label="Default select example">
                        <option selected>Choose Lamp</option>
                        <option value="1">Lamp 1</option>
                        <option value="2">Lamp 2</option>
                        <option value="3">Lamp 3</option>
                    </select>
                </form>
            </div>
            <!-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-calendar" aria-hidden="true">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                This week
            </button> -->
        </div>
    </div>
    <div class="container">
        <div id="log"></div>
        <div id="log1"></div>
        <div id="log2"></div>
    </div>
    <div class="container">
        <div class="row text-center ">
            <div class="col-lg-6">
                <h3>Lamp Power </h3>
                <canvas id="VI" width="200" height="200"></canvas>
            </div>
            <div class="col-lg-6">
                <h3>Battery</h3>
                <canvas id="batt" width="200" height="200"></canvas>
            </div>
        </div>


    </div>

    <script>
    $('#team').on('change', function() {
        var selected_option_value = $(this).find(":selected").val();
        $(location).attr("href", "<?=$url?>&section=statushourly&lamp=" + selected_option_value);
    });



    function updateVIChart() {
        let currentDate = new Date();
        let cd = currentDate.getDate();
        let scd = '';
        if (cd < 10) scd = scd + '0';
        scd = scd + String(cd);
        let cm = currentDate.getMonth() + 1;
        let scm = '';
        if (cm < 10) scm = scm + '0';
        scm = scm + String(cm);
        let cy = currentDate.getFullYear();
        $.getJSON("/status/getDataByHour.php?lamp=<?=$lamp?>&year=" + cy + "&month=" + scm + "&day=" + scd,
            function(data) {

                $.each(data, function(key, val) {
                    window.myBar.data.labels.push(val['jam']);
                    //var dataArr = [1, 2];
                    //window.myBar.data.datasets.data.push(dataArr);
                    window.myBar.data.datasets[0].data.push([val['min'] * val['batt'], val['max'] * val[
                        'batt']]);
                    chartBatt.data.labels.push(val['jam']);
                    chartBatt.data.datasets[0].data.push(val['batt']);
                    //console.log(val);
                });
                window.myBar.update();
                chartBatt.update();
            });
    }


    var ctx = document.getElementById('VI').getContext('2d');
    var data = {
        labels: [],
        datasets: [{
            label: 'min and max',
            data: [],
            backgroundColor: 'blue'
        }]
    };

    window.myBar = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Horizontal Floating Bars'
            },
            scales: {
                x: {
                    ticks: {
                        // Include a dollar sign in the ticks
                        callback: function(value, index, ticks) {
                            return value + " WIB";
                        }
                    },
                    display: true,
                    title: {
                        display: true,
                        text: 'Jam'
                    }
                },
                y: {
                    ticks: {
                        // Include a dollar sign in the ticks
                        callback: function(value, index, ticks) {
                            return value + " Watt";
                        }
                    },
                    display: true,
                    title: {
                        display: true,
                        text: 'Daya'
                    }
                }
            }
        }
    });

    var batt = document.getElementById('batt').getContext('2d');
    var chartBatt = new Chart(batt, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'VBatt (V)',
                data: [],
                backgroundColor: 'green',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                x: {
                    ticks: {
                        // Include a dollar sign in the ticks
                        callback: function(value, index, ticks) {
                            return value + " WIB";
                        }
                    },
                    display: true,
                    title: {
                        display: true,
                        text: 'Jam'
                    }
                },
                y: {
                    ticks: {
                        // Include a dollar sign in the ticks
                        callback: function(value, index, ticks) {
                            return value + " V";
                        }
                    },
                    min: 20,
                    beginAtZero: false,
                    display: true,
                    title: {
                        display: true,
                        text: 'Tegangan'
                    }
                }
            },

            animation: {
                duration: 0
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = 'Batt: ';
                            if (context.parsed.y !== null) {
                                var percent = context.parsed.y - 22;
                                percent /= (0.036);
                                percent = Math.round(percent);
                                if (percent > 100) percent = 100;
                                label += context.parsed.y + 'V (' + percent + '%)';
                            }
                            return label;
                        }
                    }
                }
            }

        }
    });

    updateVIChart();
    </script>

</main>