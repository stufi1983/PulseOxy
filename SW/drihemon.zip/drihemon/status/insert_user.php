<?php
require 'configdb.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $roles = $_POST['roles'];
    $dev = $_POST['device'];

    // Hash the password using bcrypt
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Check if the username already exist
    $sql = "SELECT * FROM users WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$username]);

    if ($stmt->rowCount() > 0) {
        echo '<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1>Duplicate entry <?=$username?> already exists</h1>
        </main>';
        echo "";
        exit();
    }else{

    // Insert user into database
    $sql = "INSERT INTO users (username, password, roles, dev) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$username, $hashedPassword, $roles, $dev]);

        // Redirect back to users list
        //header("Location: index.php");
        echo '<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1>User created successfully</h1>
        </main>';
        exit();  
    }  
}
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

// Get the host (domain)
$host = $_SERVER['HTTP_HOST'];

// Get the request URI (path and query string)
$requestUri = $_SERVER['REQUEST_URI'];

// Combine them to get the full current URL
$currentUrl = $protocol . $host . $requestUri;
//echo $requestUri;
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">User Administrative </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
            </div>
        </div>
    </div>

 <div class="container">
<!-- HTML form for creating a new user -->
<form method="POST" action="<?=$currentUrl?>" class="row g-3">
    <div class="col-auto">
        <label for="username" class="visually-hidden">Username</label>
        <input type="text" name="username" class="form-control" id="username" placeholder="Username" required>
    </div>
    <div class="col-auto">
        <label for="password" class="visually-hidden">Password</label>
        <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
    </div>
    <div class="col-auto">
        <label for="roles" class="visually-hidden">Roles</label>
        <select id="roles" name="roles" class="form-select" required>
            <option value="">--Select a role--</option>
            <option value="admin">Admin</option>
            <option value="editor">Editor</option>
            <option value="user">User</option>
        </select>
    </div>
    <div class="col-auto">
        <label for="device" class="visually-hidden">Device</label>
        <input type="text" name="device" class="form-control" id="device" placeholder="Device" required>
    </div>
    <div class="col-auto">
        <input type="submit" class="btn btn-primary" value="Create User">
    </div>
</form>
</div>
</main>