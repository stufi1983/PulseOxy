<?php
if(!isset($_SESSION['userrole'])){echo "userrole?";exit();}
if ($_SESSION['userrole']<3):?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2 text-center">Tidak diperbolehkan mengakses halaman ini</h1>
    </div>
</main>
<?php 
goto end;
endif;
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Administrative Setting</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                <!-- <button type="button" class="btn btn-sm btn-outline-secondary">Export</button> -->
            </div>
            <!-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-calendar" aria-hidden="true">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                This week
            </button> -->
        </div>
    </div>




    <div class="container">
        <div class="justify-content-md-center row ${1| ,row-cols-2,row-cols-3, auto,justify-content-md-center,|}">


            <div class="col-md-8 text-center px-5  shadow my-5 needs-validation" novalidate>
                <h1 class="mb-4 mt-2"> Change Password </h1>
                <form id="formPass" name="formPass">
                    <!-- Name input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="oldPass" class="form-control" />
                        <label class="form-label" name="oldPass" for="oldPass">Old Password</label>
                    </div>
                    <!-- Name input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="newPass1" class="form-control" />
                        <label class="form-label" name="newPass1" for="newPass1">New Password</label>
                    </div>
                    <!-- Name input -->
                    <div class="form-outline mb-4">
                        <input type="password" id="newPass2" class="form-control" />
                        <label class="form-label" for="newPass2">Retype Password</label>
                    </div>

                    <!-- Submit button -->
                    <button type="button" id="myBtn" class="btn btn-primary btn-block mb-4">Submit</button>

                    <div class="alert alert-danger" id="pswdErr"><strong>Error</strong>! Please entry dan retype new
                        password correctly!.
                    </div>
                </form>
            </div>
        </div>
    </div>

</main>
<script>
$(document).ready(function() {
    $("#pswdErr").hide();
    // Get value on button click and show alert
    $("#myBtn").click(function() {
        $("#pswdErr").hide();
        $("#pswdErr").removeClass("alert-success").addClass("alert-danger");
        var newPass1 = $("#newPass1").val();
        var newPass2 = $("#newPass2").val();
        var oldPass = $("#oldPass").val();
        if (newPass1 == "" || newPass2 == "" || oldPass == "") {
            $("#pswdErr").text("Please entry Passwords");
            $("#pswdErr").show();

        } else if (newPass1 != newPass2) {
            $("#pswdErr").text("Please re-entry correct Password");
            $("#pswdErr").show();

        } else {
            var form = $("#formPass");
            var url = "status/setPass.php";
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    oldPass: oldPass, // Second add quotes on the value.
                    newPass1: newPass1, // Second add quotes on the value.
                },
                success: function(data) {

                    // Ajax call completed successfully
                    //alert("Result:" + data);
                    if (data === "OK") {
                        $("#oldPass").val("");
                        $("#newPass1").val("");
                        $("#newPass2").val("");
                        $("#pswdErr").removeClass("alert-danger").addClass("alert-success");
                        $('#pswdErr').text("Password Change Succeed");
                        $("#pswdErr").show();
                        $('#pswdErr').fadeOut(2000);
                    } else {
                        $("#pswdErr").show();
                        $('#pswdErr').text(data);
                        $('#pswdErr').fadeOut(2000);
                    }
                },
                error: function(data) {

                    // Some error in ajax call
                    $("#pswdErr").show();
                    $('#pswdErr').text("Some Error!");
                    $('#pswdErr').fadeOut(2000);
                }
            });
        }

    });
});
</script>
<?php end: ?>