<?php

// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}

// Define session timeout duration (e.g., 15 minutes)
$timeout_duration = 900;

// Check if the user has been inactive for longer than the timeout duration
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    session_unset();     // Unset all session variables
    session_destroy();   // Destroy the session
    header("Location: login.php"); // Redirect to login page
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();

require 'configdb.php';

$id = $_GET['id'];

// Get user details for the form
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

//if (!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] !== $allowed_referrer) {
if (isset($_SERVER['HTTP_REFERER']) ) {
    //echo $_SERVER['HTTP_REFERER'];
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $roles = $_POST['roles'];
    $dev = $_POST['dev'];
//echo $dev;
    // Update only if the password field is filled
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $sql = "UPDATE users SET username = ?, password = ?, roles = ? , dev = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$username, $hashedPassword, $roles, $dev, $id]);
    } else {
        $sql = "UPDATE users SET username = ?, roles = ?, dev = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$username, $roles, $dev, $id]);
        //print_r($stmt);
    }

    // Redirect back to users list
    //header("Location: dashboard.php");
    echo '<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h1>User edited successfully</h1>
    </main>';
    exit();
}
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

// Get the host (domain)
$host = $_SERVER['HTTP_HOST'];

// Get the request URI (path and query string)
$requestUri = $_SERVER['REQUEST_URI'];

// Combine them to get the full current URL
$currentUrl = $protocol . $host . $requestUri;
?>

<!-- HTML form for editing a user -->
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h2>Edit User</h2>
    <form method="POST" action="<?=$currentUrl?>&id=<?= $user['id'] ?>">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password (leave blank if unchanged)</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
        <div class="mb-3">
            <label for="dev" class="form-label">Device</label>
            <input type="text" class="form-control" id="dev" name="dev" value="<?= htmlspecialchars($user['dev']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="roles" class="form-label">Role</label>
            <select class="form-select" id="roles" name="roles" required>
                <option value="admin" <?= ($user['roles'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                <option value="editor" <?= ($user['roles'] == 'editor') ? 'selected' : '' ?>>Editor</option>
                <option value="user" <?= ($user['roles'] == 'user') ? 'selected' : '' ?>>User</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update User</button>
    </form>
</main>
