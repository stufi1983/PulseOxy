<?php
/*

echo '
{
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "properties": {
            "name":"-70 db"
        },
        "geometry": {
          "type": "Polygon",
          "coordinates": [
            [
              [109.27183270454407, -7.413303681357537],
              [109.27188634872437, -7.413793082270258],
              [109.27189707756042, -7.414133534758291],
              [109.2720365524292, -7.4144314304693735],
              [109.2724871635437, -7.414463347855037],
              [109.2728841304779, -7.414218647839177],
              [109.27296996116638, -7.413782443125759],
              [109.27284121513367, -7.413303681357537],
              [109.27269101142883, -7.413090898182346],
              [109.27216529846191, -7.413016424046742],
              [109.27183270454407, -7.413303681357537]
            ]
          ]
        }
      }
    ]
  }
  ';
  */
  if(!isset($_GET['db'])) exit();
  $db=''; if(isset($_GET['db'])) $db=$_GET['db'];

  include_once("../configdb.php");				
  $mysqli = $dblink;


$coordinates = array();

if ($result = $mysqli -> query("SELECT longitude, latitude FROM signalstrength WHERE rssi >= ".$db."")) {
    if($result -> num_rows > 0){        
        while ($row = $result -> fetch_row()): 
            array_push($coordinates,$row);
        endwhile;
    }
    // Free result set
    $result -> free_result();
}

require_once('phpconvexhull/phpconvexhull.php');
$coordinates=convexHull($coordinates);

$geoType = array(
    "type"=>"Polygon",
    "coordinates" => array($coordinates)
);
 
$jayParsedAry = array (
    'type' => 'FeatureCollection',
    'features' => array(
        array(
            "type"=> "Feature",
            "properties"=> array(
                "name"=>"-70db"
            ) ,
            "geometry"=> $geoType,
        )
    ),
    
);
 
    echo  json_encode($jayParsedAry);
    $mysqli -> close();

 ?>