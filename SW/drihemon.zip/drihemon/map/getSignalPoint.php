<?php
/*
echo '
{
  "type": "FeatureCollection",
  "features": [
    { "type": "Feature", "properties": { "name": "Lampu 1", "strength": -50 }, "geometry": { "type": "Point", "coordinates": [109.27217066287994, -7.412826248964738] } },
    { "type": "Feature", "properties": { "name": "Lampu 1", "strength": -70 }, "geometry": { "type": "Point", "coordinates": [109.27217166287994, -7.41286348964738] } },
    { "type": "Feature", "properties": { "name": "Lampu 1", "strength": -50 }, "geometry": { "type": "Point", "coordinates": [109.27217166287994, -7.41296348964738] } },
    { "type": "Feature", "properties": { "name": "Lampu 2", "strength": -23 }, "geometry": { "type": "Point", "coordinates": [109.27222967147827, -7.4137718039810165] } }
  ]
}

';exit();

{
  "type":"FeatureCollection",
  "features":[
    {"type":"Feature","properties":{"name":"-70db"},"geometry":{"type":"Point","coordinates":[109.27194535732269,-7.414053741230017]}},
    {"type":"Feature","properties":{"name":"-70db"},"geometry":{"type":"Point","coordinates":[109.27249252796173,-7.413888834559116]}},
    {"type":"Feature","properties":{"name":"-70db"},"geometry":{"type":"Point","coordinates":[109.27227795124054,-7.413915432413438]}},
    {"type":"Feature","properties":{"name":"-70db"},"geometry":{"type":"Point","coordinates":[109.27195608615875,-7.413511144854343]}}
    ]
  }

  */
  if(!isset($_GET['db'])) exit();
  $db=''; if(isset($_GET['db'])) $db=$_GET['db'];

  include_once("../configdb.php");				
  $mysqli = $dblink;


$features = array();

if ($result = $mysqli -> query("SELECT longitude, latitude FROM signalstrength WHERE rssi >= ".$db."")) {
    if($result -> num_rows > 0){        
        while ($row = $result -> fetch_row()): 
          $geoType = array(
            "type"=>"Point",
            "coordinates" => array(floatval($row[0]),floatval($row[1]))
          );
          $feature= array(
            "type"=> "Feature",
            "properties"=> array(
                "name"=>"-70db"
            ) ,
            "geometry"=> $geoType,
            );
          array_push($features,$feature);
        endwhile;
    }
    // Free result set
    $result -> free_result();
}





 
$jayParsedAry = array (
    'type' => 'FeatureCollection',
    'features' => $features,
    
);
 
    echo  json_encode($jayParsedAry);
    $mysqli -> close();

 ?>