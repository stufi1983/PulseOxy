<footer class="container-fluid py-5" style="background-color: #eaeaea;">
    <div class="row  justify-content-md-center">
        <!-- <div class="col text-center">
            <img src="images/favicon.png" style="background-color: #eaeaea;" alt="Smart PJU" width="200"
                class="img-thumbnail px-5">
        </div> -->
        <div class="col text-start mx-5">
            <h5>Features</h5>
            <ul class="list-unstyled text-small">
                <li><a class="link-secondary" href="#">Hardware</a></li>
                <li><a class="link-secondary" href="#">Configuration</a></li>
                <li><a class="link-secondary" href="#">Requirement</a></li>
            </ul>
        </div>
        <div class="col mx-5">
            <h5>Resources</h5>
            <ul class="list-unstyled text-small">
                <li><a class="link-secondary" href="#">Research Group</a></li>
                <li><a class="link-secondary" href="#">Foundation</a></li>
                <li><a class="link-secondary" href="#">Contact Us</a></li>
            </ul>
        </div>
    </div>
</footer>
<footer class="footer mt-auto py-3 bg-light">
    <div class="container  text-center">
        <span class="text-muted ">Copyright (C) Teknik Elektro UMP 2024</span>
    </div>

    
</footer>