<?php
    session_start();
	include("head.php");
?>

<body>
    <?php 
			include_once("navbar.php");
			if(!isset($_GET['nav'])||!isset($_SESSION['username']))
				include_once("home.php");
			else{
				
				$nav=$_GET['nav']."/".$_GET['nav'].".php";
				if(file_exists($nav))
					include_once($nav);
				else
					include($_GET['nav'].".php");
			}
			include_once("footer.php");
		?>
</body>

</html>