<?php

$lamp = 1;
if(isset($_GET['lamp']))
{
    $lamp = $_GET['lamp'];
}
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <?php
// echo "G";print_r($_GET);
// echo "S";print_r($_SESSION);
// echo "P";print_r($_POST);
include_once("configdb.php");

$userid=0;
$realname="";
$sql="SELECT `users`.`id`,`users`.`realname` FROM `users` WHERE  `users`.`username`='".$_SESSION['username']."' GROUP BY `users`.`username` ORDER BY `username` ASC;";
if(isset($_GET['id'])){
    $userid = $_GET['id'];
    $sql="SELECT `users`.`id`,`users`.`realname` FROM `users` WHERE  `users`.`id`='".$userid."' GROUP BY `users`.`username` ORDER BY `username` ASC;";
}
if ($result = $dblink -> query($sql)){
    if($result -> num_rows > 0){
        while ( $row = $result->fetch_assoc())  {
            $userid= $row['id'];
            $realname= $row['realname'];
        }
    }
}

?>
    <div class="chartjs-size-monitor">
        <div class="chartjs-size-monitor-expand">
            <div class=""></div>
        </div>
        <div class="chartjs-size-monitor-shrink">
            <div class=""></div>
        </div>
    </div>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Current Day View of
            <?=$realname?>'s Health
            <span class="label label-info" id="health-status">Live</span>
        </h1>
        
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="mt-1 me-2">Person Name </div>
            <div class="btn-group me-2">
                <form>
                    <select class="form-select" id="team" aria-label="Default select example">
                        <option value="0" default>-- Please Select Name --</option>';
                        <?php
                        include_once("configdb.php");
                        $mysqli = $dblink;
                        print_r($_SESSION);

                        $sql="SELECT `users`.`id`, `users`.`realname` FROM `health_data`,`users` WHERE `users`.`dev`=`health_data`.`dev` AND `users`.`username`='".$_SESSION['username']."' GROUP BY `users`.`username` ORDER BY `realname` ASC;";
                        if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'editor'){
                            $sql="SELECT `users`.`id`, `users`.`realname` FROM `health_data`,`users` WHERE `users`.`dev`=`health_data`.`dev` GROUP BY `users`.`username` ORDER BY `realname` ASC;";
                        }
                        if ($result = $mysqli -> query($sql)) {
                            if($result -> num_rows > 0){
                                while ( $row = $result->fetch_assoc())  {
                                    echo '<option value="'.$row['id'].'">'.$row['realname'].'</option>';
                                }
                            }
                        }
                        ?>
                    </select>
                </form>
            </div>
            <!-- <button type="button" class="btn btn-sm btn-outline-secondary
            dropdown-toggle"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
            stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"
            aria-hidden="true"> <rect x="3" y="4" width="18" height="18" rx="2"
            ry="2"></rect> <line x1="16" y1="2" x2="16" y2="6"></line> <line x1="8" y1="2"
            x2="8" y2="6"></line> <line x1="3" y1="10" x2="21" y2="10"></line> </svg> This
            week </button> -->
        </div>
    </div>
    <div class="container">
        <div id="log"></div>
        <div id="log1"></div>
        <div id="log2"></div>
    </div>
    <div class="container" id="content">
        <div class="row text-center ">
            <div class="col-lg-6">
                <h3>Blood Pressure</h3>
                <canvas id="VI" width="200" height="200"></canvas>
            </div>
            <div class="col-lg-6">
                <h3>Oxigen Saturation</h3>
                <canvas id="batt" width="200" height="200"></canvas>
            </div>
        </div>
        <!-- devBatt -->
        <div class="row text-center ">
            <div class="col-lg-6">
                <h3>Heart Rate</h3>
                <canvas id="daya" width="200" height="200"></canvas>
            </div>
            <div class="col-lg-6">
                <h3>Battery Level</h3>
                <canvas id="devBatt" width="200" height="200"></canvas>
            </div>
        </div>

    </div>

    <script>

        $('#team').on('change', function () {
            var selected_option_value = $(this)
                .find(":selected")
                .val();
            $(location).attr(
                "href",
                "<?=$url?>&section=statushourly&id=" + selected_option_value
            );
        });

        const DATA_COUNT = 7;
        const NUMBER_CFG = {
            count: DATA_COUNT,
            min: -100,
            max: 100
        };

        const data = {
            labels: [],
            datasets: [
                {
                    label: 'Sistole',
                    data: [],
                    borderColor: 'rgba(100, 99, 255, 0.8)',
                    backgroundColor: 'rgba(100, 99, 255, 0.5)',
                    yAxisID: 'y0'
                }, {
                    label: 'Diastole',
                    data: [],
                    borderColor: 'rgba(0, 255, 0, 0.8)',
                    backgroundColor: 'rgba(0, 255, 0, 0.5)',
                    yAxisID: 'y1'
                }
            ]
        };
        const config = {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                stacked: false,
                plugins: {
                    title: {
                        display: false,
                        text: ''
                    }
                },
                scales: {
                    y0: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: false,
                        steps: 10,
                        stepValue: 5,
                        min: 80,
                        //max: 200,
                        ticks: {
                            color: 'rgba(100, 100, 255, 1)'
                        },
                        title: {
                            display: true,
                            text: 'Sistole (mmHg)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: false,
                        steps: 10,
                        stepValue: 5,
                        max: 100,
                        ticks: {
                            color: 'rgba(0, 255, 0, 1)'
                        },
                        // grid line settings
                        grid: {
                            drawOnChartArea: false, // only want the grid lines for one axis to show up
                        },
                        title: {
                            display: true,
                            text: 'Diastole (mmHg)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                },
                animation: {
                    duration: 0
                }
            }
        };

        const VIChart = new Chart(document.getElementById('VI'), config);

        var daya = document
            .getElementById('daya')
            .getContext('2d');
        var dayaChart = new Chart(daya, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'Rate (BPM)',
                        data: data
                            .datasets[0]
                            .data,
                        backgroundColor: 'rgba(255, 99, 132, 1)',
                        borderColor: 'rgba(250, 94, 130, 1)',
                        borderWidth: 2
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: false,
                        steps: 10,
                        stepValue: 5,
                        min: 50,
                        max: 150,
                        ticks: {
                            // color: 'rgba(255, 99, 132, 1)',
                        },
                        title: {
                            display: true,
                            text: 'Rate (BPM)'
                        },
                        beginAtZero: false
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                },

                animation: {
                    duration: 0
                }

            }
        });

        var batt = document
            .getElementById('batt')
            .getContext('2d');
        var chartBatt = new Chart(batt, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'SPO2 Value',
                        data: data
                            .datasets[0]
                            .data,
                        backgroundColor: 'green',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        min: 75,
                        title: {
                            display: true,
                            text: 'Saturation (%)'
                        },
                        beginAtZero: false
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                },
                animation: {
                    duration: 0
                }

            }
        });

        var devBatt = document
            .getElementById('devBatt')
            .getContext('2d');
        var chartDevBatt = new Chart(devBatt, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'Battery',
                        data: data
                            .datasets[0]
                            .data,
                        backgroundColor: 'blue',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        //min: 75,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Batt Level (%)'
                        },
                        beginAtZero: false
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                },
                animation: {
                    duration: 0
                }

            }
        });

        function addData(chart, label, data) {
            if (chart.data.labels.length > maxData) {
                chart
                    .data
                    .labels
                    .shift();
            }
            chart
                .data
                .labels
                .push(label);
            chart
                .data
                .datasets
                .forEach((dataset) => {
                    if (dataset.data.length > maxData) {
                        dataset
                            .data
                            .shift();
                    }
                    dataset
                        .data
                        .push(data);
                });
            chart.update();
        }

        var filePath = 'status/getDataByHour.php?lamp=<?=$userid?>';

        function updateVIChart(chart, chartDaya, cd, cm, cy) {
            //let currentDate = new Date();
            // let cd = currentDate.getDate()-1;
            let scd = '';
            if (cd < 10) 
                scd = scd + '0';
            scd = scd + String(cd);
            // let cm = currentDate.getMonth() + 1;
            let scm = '';
            if (cm < 10) 
                scm = scm + '0';
            scm = scm + String(cm);
            // let cy = currentDate.getFullYear();
            var path = filePath + "&year=" + cy + "&month=" + scm + "&day=" + scd;
            $.getJSON(path, function (data) {
                var getlabel = [];
                var ds0 = [];
                var ds1 = [];
                var daya = [];
                var color = [];
                var batt = [];
                var battLabel = '';
                var devBattColor = [];
                var devBatt = [];
                var devBattLabel = '';
                console.log(data);
                if(data.length == 0)
                {
                    //alert("No data available!");
                    var d = new Date();
                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var n = d.toLocaleDateString('id-ID', options);
                    //console.log(n);
                    $('#content').html('<h1>No Data Available on '+n+'</h1>');
                    return;
                }
                
                ///console.log(data);

                $.each(data, function (key, val) {
                    getlabel.push(val['jam']);
                    ds0.push(val['sis']);
                    ds1.push(val['dia']);
                    daya.push(val['hrr']);
                    batt.push(val['spo']);

                    if (val['spo'] < 90) {
                        battLabel = 'Critical SPO2 value';
                        color.push('red');
                    } else if (val['spo'] < 95) {
                        battLabel = 'Low SPO2 value';
                        color.push('orange');
                    } else {
                        battLabel = 'SPO2 value';
                        color.push('green');
                    }

                    devBatt.push(val['bat']);

                    if (val['bat'] < 10) {
                        devBattLabel = 'Critical Batt';
                        devBattColor.push('red');
                    } else if (val['bat'] < 40) {
                        devBattLabel = 'Low Batt';
                        devBattColor.push('orange');
                    } else {
                        devBattLabel = 'Battery Percentage';
                        devBattColor.push('blue');
                    }

                    var hs = "OK";
                    $('#health-status')
                        .text("OK")
                        .css('color', 'red');
                    if (val['sis'] > 120) 
                        hs = "HYPERTENSION";
                    if (val['dia'] > 80) 
                        hs = "HYPOTENSION";
                    if (val['bpm'] > 100) 
                        hs = "PALPITASION";
                    if (val['spo'] < 95) 
                        hs = "HYPOXEMIA";
                    $('#health-status').text(hs);
                    if (hs != "OK") 
                        $("#health-status").css('color', 'red');

                    }
                );

                if (!arrayEquals(chart.data.labels, getlabel)) {
                    chart.data.labels = getlabel;
                    chart
                        .data
                        .datasets[0]
                        .data = ds0;
                    chart
                        .data
                        .datasets[1]
                        .data = ds1;

                    chart.update();
                    chartDaya.data.labels = getlabel;
                    chartDaya
                        .data
                        .datasets[0]
                        .data = daya;
                    chartDaya.update();

                    chartBatt.data.labels = getlabel;
                    chartBatt
                        .data
                        .datasets[0]
                        .data = batt;
                    chartBatt
                        .data
                        .datasets[0]
                        .backgroundColor = color;
                    chartBatt
                        .data
                        .datasets[0]
                        .borderColor = color;
                    chartBatt
                        .data
                        .datasets[0]
                        .label = battLabel;
                    chartBatt
                        .data
                        .datasets[0]
                        .backgroundColor = color;
                    chartBatt.update();
                    //chartDevBatt
                    chartDevBatt.data.labels = getlabel;
                    chartDevBatt
                        .data
                        .datasets[0]
                        .data = devBatt;
                    chartDevBatt
                        .data
                        .datasets[0]
                        .backgroundColor = devBattColor;
                    chartDevBatt
                        .data
                        .datasets[0]
                        .borderColor = devBattColor;
                    chartDevBatt
                        .data
                        .datasets[0]
                        .label = devBattLabel;
                    chartDevBatt
                        .data
                        .datasets[0]
                        .backgroundColor = devBattColor;
                    chartDevBatt.update();
                }
                // $('#log').text(chart.data.datasets[0].data);
                // $('#log1').text(chart.data.datasets[1].data);
                // $('#log2').text(chart.data.labels);
            });
        }

        function arrayEquals(a, b) {
            return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every(
                (val, index) => val === b[index]
            );
        }
        // setInterval(function() {     updateVIChart(VIChart, dayaChart);
        // $.getJSON(filePath, function(data) {          $.each(data, function(key, val)
        // {              var currentDate = new Date();              let time =
        // currentDate.getHours() + ":" + currentDate.getMinutes() + ":" +
        // currentDate.getSeconds();              addData(voltageChart, time,
        // val['voltage']);              addData(frequencyChart, time,
        // val['frequency']);              addData(currentChart, time, val['current']);
        // addData(tempChart, time, val['temperature']); addData(humidityChart, time,
        // val['humidity']); updateDrownBurn(val['drown'], val['burn']);          });
        // }); }, 2000);
        //updateVIChart(VIChart, dayaChart);

        let currentDate = new Date();
        updateVIChart(VIChart, dayaChart, currentDate.getDate(), currentDate.getMonth() + 1, currentDate.getFullYear());

    </script>

</main>