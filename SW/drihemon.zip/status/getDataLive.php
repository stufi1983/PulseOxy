<?php

include_once("../configdb.php");
//Fetch 3 rows from actor table
//$sql="SELECT `users`.`id` FROM `health_data`,`users` WHERE `users`.`dev`=`health_data`.`dev` AND `users`.`id`='".$_GET['lamp']."' GROUP BY `users`.`username` ORDER BY `username` ASC;";
$sql="SELECT TIME(`health_data`.`timestamp`) as jam, dia, sis, hrr, spo, bat FROM `users`,`health_data` WHERE `users`.`dev`=`health_data`.`dev`AND `users`.`id`=".$_GET['lamp']." ORDER BY `health_data`.`timestamp` ASC;";
	$result = $dblink->query($sql);
//$result = $dblink->query("SELECT TIME(waktu) as jam,tegangan,arus,temp FROM ( SELECT * FROM status_lampu WHERE id_lampu=".$_GET['lamp']." ORDER BY waktu DESC LIMIT 20 )Var1 ORDER BY id ASC");

//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);
 
?>