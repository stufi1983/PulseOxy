<?php
if(!isset($_SESSION['userrole'])){echo "userrole?";exit();}
//echo print_r($_SESSION);
if ($_SESSION['userrole']!="admin" && $_SESSION['userrole']!="editor"):?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2 text-center">Tidak diperbolehkan mengakses halaman ini</h1>
    </div>
</main>
<?php 
goto end;
endif;
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">User Administrative </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <!-- <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
            </div> -->
        </div>
    </div>

<?php

// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // If not logged in, redirect to the login page
    //header("Location: login.php");
    exit();
}

// Define session timeout duration (e.g., 15 minutes)
$timeout_duration = 900;

// Check if the user has been inactive for longer than the timeout duration
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    session_unset();     // Unset all session variables
    session_destroy();   // Destroy the session
    //header("Location: login.php"); // Redirect to login page
    exit();
}

// Update the last activity timestamp
$_SESSION['last_activity'] = time();


// echo "Welcome, " . $_SESSION['username'] . "!<br>";
// echo "Your role is: " . $_SESSION['user_role'] . "<br>";

require 'configdb.php';

$stmt = $conn->query("SELECT * FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


    <div class="container">
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Real Name</th>
                    <th>Role</th>
                    <th>Device</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= $user['username'] ?></td>
                    <td><?= $user['realname'] ?></td>
                    <td><?= $user['roles'] ?></td>
                    <td><?= $user['dev'] ?></td>
                    <td class="text-center">
                        <a href="viewdata.php?dev=<?= htmlspecialchars($user['dev']) ?>" class="btn btn-primary btn-sm">View</a>
                        <?php if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'editor'): ?>
                            <a href="index.php?id=<?= htmlspecialchars($user['id'])?>&nav=<?= $_GET['nav']?>&section=edit_user" class="btn btn-primary btn-sm">Edit</a>
                        <?php endif; ?>
                        <?php if ($_SESSION['user_role'] === 'admin'): ?>
                            <a href="delete_user.php?id=<?= htmlspecialchars($user['id']) ?>" onclick="return confirm('Are you sure you want to delete this user?')" class="btn btn-danger btn-sm">Delete</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'editor'): ?>
            <a href="index.php?id=<?= htmlspecialchars($user['id'])?>&nav=<?= $_GET['nav']?>&section=insert_user" class="btn btn-success mt-3">Add New User</a>
        <?php endif; ?>
    </div>


</main>
<script>
$(document).ready(function() {
    $("#pswdErr").hide();
    // Get value on button click and show alert
    $("#myBtn").click(function() {
        $("#pswdErr").hide();
        $("#pswdErr").removeClass("alert-success").addClass("alert-danger");
        var newPass1 = $("#newPass1").val();
        var newPass2 = $("#newPass2").val();
        var oldPass = $("#oldPass").val();
        if (newPass1 == "" || newPass2 == "" || oldPass == "") {
            $("#pswdErr").text("Please entry Passwords");
            $("#pswdErr").show();

        } else if (newPass1 != newPass2) {
            $("#pswdErr").text("Please re-entry correct Password");
            $("#pswdErr").show();

        } else {
            var form = $("#formPass");
            var url = "status/setPass.php";
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    oldPass: oldPass, // Second add quotes on the value.
                    newPass1: newPass1, // Second add quotes on the value.
                },
                success: function(data) {

                    // Ajax call completed successfully
                    //alert("Result:" + data);
                    if (data === "OK") {
                        $("#oldPass").val("");
                        $("#newPass1").val("");
                        $("#newPass2").val("");
                        $("#pswdErr").removeClass("alert-danger").addClass("alert-success");
                        $('#pswdErr').text("Password Change Succeed");
                        $("#pswdErr").show();
                        $('#pswdErr').fadeOut(2000);
                    } else {
                        $("#pswdErr").show();
                        $('#pswdErr').text(data);
                        $('#pswdErr').fadeOut(2000);
                    }
                },
                error: function(data) {

                    // Some error in ajax call
                    $("#pswdErr").show();
                    $('#pswdErr').text("Some Error!");
                    $('#pswdErr').fadeOut(2000);
                }
            });
        }

    });
});
</script>
<?php end: ?>