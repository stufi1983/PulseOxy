<?php
$lamp = 1;
if(isset($_GET['lamp']))
{
    $lamp = $_GET['lamp'];
}
if(!isset($_SESSION['userrole'])){echo "userrole?";exit();}
if ($_SESSION['userrole']>1):?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2 text-center">Tidak diperbolehkan mengakses halaman ini</h1>
    </div>
</main>
<?php 
goto end;
endif;
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Setting for Lamp #<?=$lamp?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <!-- <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button> -->
                <form>
                    <select class="form-select" id="team" aria-label="Default select example">
                        <option selected>Choose Lamp</option>
                        <option value="1">Lamp 1</option>
                        <option value="2">Lamp 2</option>
                        <option value="3">Lamp 3</option>
                    </select>
                </form>
            </div>
            <!-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-calendar" aria-hidden="true">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                This week
            </button>
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown button
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </div> -->
        </div>
    </div>




    <div class="container">
        <form class="row g-3 shadow  needs-validation justify-content-md-center text-center" id="formIdTgl" novalidate>
            <h1> Power management </h1>
            <div class="col-md-8">
                <label for="setDayaLampu" class="form-label">Set Lamp Power </label>
                <select class="form-select" id="setDayaLampu" name="val" required>
                    <option selected disabled value="">Choose...</option>
                    <option value="-1">Automatic</option>
                    <option value="0">0 % (OFF)</option>
                    <option value="50">50 % (Dimm)</option>
                    <option value="75">75 % (Normal)</option>
                    <option value="100">100 % (Bright)</option>
                </select>
            </div>

            <div class="col-md-8 ">
                <input type="checkbox" id="dt" name="dt">
                <label for="dt">Update Lamp Clock as Current Time</label>
            </div>
            <div class="col-md-8  d-grid gap-2">
                <input type="hidden" name="lamp" value="<?=$lamp?>">
                <button class="btn btn-primary py-3" id="submitButtonTgl" type="button">Send</button>
            </div>

            <div class="col-md-8 ">
                <h2 id="notifTgl"></h2>
            </div>
        </form>
        <div class="row my-3 ${1| ,row-cols-2,row-cols-3, auto,justify-content-md-center,|}">
            -
        </div>
        <form class="row g-3 shadow  needs-validation justify-content-md-center text-center" id="formIdSchedeule"
            novalidate>
            <h1>Time Scheduling </h1>
            <h2>Coming soon....</h2>
            <div class="col-md-8  d-grid gap-2">
                <input type="hidden" name="lamp" value="<?=$lamp?>">
                <button class="btn btn-primary py-3" id="submitButtonTgl" type="button">Send</button>
            </div>

            <div class="col-md-8 ">
                <h2 id="notifSchedule"></h2>
            </div>
        </form>
        <div class="row my-3 ${1| ,row-cols-2,row-cols-3, auto,justify-content-md-center,|}">
            -
        </div>
    </div>

</main>

<script>
$('#team').on('change', function() {
    var selected_option_value = $(this).find(":selected").val();
    $(location).attr("href", "<?=$url?>&section=statussetting&lamp=" + selected_option_value);
});
$(function() {
    $('#team').selectpicker();
    $("#team").on("changed.bs.select", function(e, clickedIndex, isSelected, oldValue) {
        if (clickedIndex == null && isSelected == null) {
            var selectedItems = ($(this).selectpicker('val') || []).length;
            var allItems = $(this).find('option:not([disabled])').length;
            if (selectedItems == allItems) {
                console.log('seleted all');
            } else {
                console.log('deseleted all');
            }
        } else {
            var selectedD = $(this).find('option').eq(clickedIndex).text();
            console.log('selectedD: ' + selectedD + ' oldValue: ' + oldValue);
        }
    });
});

// When DOM is loaded this 
// function will get executed
$(() => {

    $("#submitButtonTgl").click(function(ev) {
        $('#notifTgl').text("");
        $('#notifTgl').fadeIn(1);
        var form = $("#formIdTgl");
        var url = "status/setLamputgl.php";
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize(),
            success: function(data) {

                // Ajax call completed successfully
                //alert("Result:" + data);
                $('#notifTgl').text(data);
                $('#notifTgl').fadeOut(2000);

            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                //alert('Error - ' + errorMessage);
            }
        });
    });
});
</script>
<?php end: ?>