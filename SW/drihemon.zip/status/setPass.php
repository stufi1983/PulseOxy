<?php
session_start();
require_once("../configdb.php");
if(!isset($_POST['oldPass']) || !isset($_POST['newPass1'])) {echo "???"; exit();}
$sql = "SELECT id, pswd FROM pengguna WHERE user='".$_SESSION['username']."' AND pswd='".$_POST['oldPass']."'";
//  echo $sql;

$result = $dblink->query($sql);
if($result==null){
    echo "Query Err";
    exit();
}
// print_r($result);

if($result -> num_rows > 0){
    while ( $row = $result->fetch_assoc())  {
        $id=$row['id'];
      }
    //   echo $id;
    $sql="UPDATE `pengguna` SET `pswd` = '".$_POST['newPass1']."' WHERE `id` = ".$id.";";
    if ($dblink->query($sql) === TRUE) {
    echo "OK";
    } else {
    echo "Error: " . $sql . "<br>" . $dblink->error;
    }
}else{
    echo "Invalid Old Password!";
}

exit();
//Initialize array variable
$dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }
echo $dbdata[0];
  
// $val = intval(abs($_POST['val'] * 255 / 100));
// $sql = "INSERT INTO `setting_lampu` (`id`, `id_lampu`, `command`, `val`,`status`) VALUES (NULL, 1, 'I','".$val."', 'WAIT')";
// if ($dblink->query($sql) === TRUE) {
//     echo "OK";
//     } else {
//     echo "Error: " . $sql . "<br>" . $dblink->error;
//     }
//     $dblink->close();

?>