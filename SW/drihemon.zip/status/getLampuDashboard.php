<?php
    $id=0;
    if(isset($_GET['id'])) $id=$_GET['id'];
	$user="Unknown";
    $mode = "Unknown";
	$bat="N/A";
	$sis="N";
	$dia="A";
	$hrr="N/A";
	$spo="N/A";
	$kon="N/A";
	$con="N/A";
	$lastSeen="";
	$realname="";
	if($id==0){
		echo json_encode(array($user, $mode, $bat, $sis, $dia, $hrr, $spo, $kon, $con, $lastSeen, $realname));
		exit();
	}
	include_once("../configdb.php");
	$mysqli = $dblink;
	
	
	$sql="SELECT * FROM `users`,`health_data` WHERE `users`.`dev`=`health_data`.`dev`AND `users`.`id`=".$id." ORDER BY `health_data`.`timestamp` DESC LIMIT 1;";
	if ($result = $mysqli -> query($sql)) {
		if($result -> num_rows > 0){
			while ( $row = $result->fetch_assoc())  {
				if($row['con']=='1') 
                $mode = "Connected";
                else 
                $mode = "Disconnected "; 
				$lastSeen = $row['timestamp'];
				$user = $row['dev'];
				$kon = $row['kon'];
				$con = $row['con'];
				$bat = $row['bat'];
				$sis = $row['sis'];
				$dia = $row['dia'];
				$hrr = $row['hrr'];
				$spo = $row['spo'];
				$user = $row['username'];
				$realname = $row['realname'];
            }
            
        }
    }
	//$sql="SELECT * FROM  `status_lampu` WHERE id_lampu=".$id." /*AND waktu >= DATE_SUB(NOW(),INTERVAL 30 SECOND)*/ ORDER BY ID DESC LIMIT 1";
	/*
	if ($result = $mysqli -> query($sql)) {
		if($result -> num_rows > 0){
			while ( $row = $result->fetch_assoc())  {
				$power =  round($row['arus'] * $row['tegangan'], 2); 
                // $batt = round ($row['tegangan'] * 100 / 26) ;
				$batt = $row['tegangan'] - 22;
                $batt /= (0.036);
                $batt = round($batt);
                if ($batt > 100) $batt = 100;
                //  echo json_encode($row,JSON_NUMERIC_CHECK);
				if($batt> 50) $battstatus = "OK";
				else if($batt > 20) $battstatus = "LOW";
				else $battstatus = "Critical";
            }
			$sql="SELECT DATE_FORMAT(waktu, '%d-%m-%Y %H.%i.%s') as time, waktu >= DATE_SUB(NOW(),INTERVAL 30 SECOND) as online FROM  `status_lampu` WHERE id_lampu=".$id." ORDER BY ID DESC LIMIT 1";
			if ($result = $mysqli -> query($sql)) {
				if($result -> num_rows > 0){
					while ( $row = $result->fetch_assoc())  {

						$lastSeen = "Last Seen: ".$row['time'];
						if($row['online']==0){
							$status = "Disconnected";
						}
					}
				}
			}

            
        }else{
			$status = "Disconnected";
			$sql="SELECT DATE_FORMAT(waktu, '%d-%m-%Y %H.%i.%s') as time FROM  `status_lampu` WHERE id_lampu=".$id." ORDER BY ID DESC LIMIT 1";
			if ($result = $mysqli -> query($sql)) {
				if($result -> num_rows > 0){
					while ( $row = $result->fetch_assoc())  {

						$lastSeen = "Last Seen: ".$row['time'];
					}
				}
			}
		}
    }*/
	echo json_encode(array($user, $mode, $bat, $sis, $dia, $hrr, $spo, $kon, $con, $lastSeen, $realname));
	?>