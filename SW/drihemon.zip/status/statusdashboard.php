<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <button
                    type="button"
                    class="btn btn-sm btn-outline-secondary"
                    id="refreshButton">
                    Refresh</button>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="table-responsive-lg">
            <table class="table text-center">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Real<br/>Name</th>
                        <th scope="col">Connection<br/>Status</th>
                        <th scope="col">Battery<br/>%</th>
                        <th scope="col">Blood Pressure<br/>(mmHg)</th>
                        <th scope="col">Heart Rate<br/>(BPM)</th>
                        <th scope="col">Oxygen
                            <br/>%</th>
                        <th scope="col">Health
                            <br/>Condition</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                include_once("configdb.php");
                $mysqli = $dblink;
                //print_r($_SESSION);

                $sql="SELECT `users`.`id` FROM `health_data`,`users` WHERE `users`.`dev`=`health_data`.`dev` AND `users`.`username`='".$_SESSION['username']."' GROUP BY `users`.`username` ORDER BY `username` ASC;";
                if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'editor'){
                    $sql="SELECT `users`.`id` FROM `health_data`,`users` WHERE `users`.`dev`=`health_data`.`dev` GROUP BY `users`.`username` ORDER BY `username` ASC;";
                }
                $userarray = array();
                if ($result = $mysqli -> query($sql)) {
                    if($result -> num_rows > 0){
                        while ( $row = $result->fetch_assoc())  {
                            array_push($userarray, $row['id']);
                            ?>
                    <tr>
                        <th scope="row" id="user<?=$row['id']?>"><?=$row['id']?></th>
                        <td>
                            <span id="mode<?=$row['id']?>"></span><br/>
                            <span id="lastSeen<?=$row['id']?>"></span>
                        </td>
                        <td id="bat<?=$row['id']?>"></td>
                        <td id="sisdis<?=$row['id']?>"></td>
                        <td id="hrr<?=$row['id']?>"></td>
                        <td id="spo<?=$row['id']?>"></td>
                        <td id="kon<?=$row['id']?>"></td>

                        <td>
                            <a href="<?=$url?>&section=statuslive&id=<?=$row['id']?>">
                                <button type="button" class="btn btn-outline-success">Live View</button>
                            </a>
                        </td>
                    </tr>

                    <?php
                        }
                    }
                }            
                ?>
                </tbody>
            </table>
        </div>
    </div>

</main>
<script>
    var jsArray = <?php echo json_encode($userarray); ?>;
    console.log(jsArray);
    $(() => {

        function getData(uid) {
            var url = "status/getLampuDashboard.php?id=" + uid;
            $.ajax({
                type: "POST",
                url: url,
                data: {},
                success: function (data) {

                    var result = JSON.parse(data);
                    $('#user'+uid).text(result[10]);
                    $('#con'+uid).text(result[1]);
                    $('#bat'+uid).text(result[2]);
                    $('#sisdis'+uid).text(result[3] + '/' + result[4]);
                    $('#hrr'+uid).text(result[5]);
                    $('#spo'+uid).text(result[6]);
                    if (result[7] == '1') 
                        $('#kon'+uid).text('Healthy');
                    else if (result[7] == '0') 
                        $('#kon'+uid).text('not Healthy');
                    else 
                        $('#kon'+uid).text('Unknown');
                    $('#mode'+uid).text(result[1]);

                    let dt = new Date(result[9]);

                    // Format the date and time in a readable way
                    let options = {
                        timeZone: 'Asia/Jakarta',
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: false
                    };

                    let formattedDate = dt.toLocaleString('en-GB', options);

                    $('#lastSeen'+uid).text(formattedDate);

                    //console.log(result);

                },
                error: function (xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    // alert('Error - ' + errorMessage);
                }
            });
        }

        function getDataAll() {
            jsArray.forEach(getData);
            //getData(2);
        }

        $("#refreshButton").click(function (ev) {
            getDataAll();
        });

        setInterval(function () {
            getDataAll();
        }, 3333);

        getDataAll();

    });
</script>