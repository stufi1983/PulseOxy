<?php

include_once("../configdb.php");
//Fetch 3 rows from actor table
//$sql="SELECT TIME(`health_data`.`timestamp`) as jam, ROUND( AVG( dia ),0) as dia , ROUND( AVG( sis ),0) as sis, ROUND( AVG( hrr ),0) as hrr, ROUND( AVG( spo ),0) as spo, ROUND( AVG( bat ),0) as bat FROM `users`,`health_data` WHERE `health_data`.`timestamp` LIKE '".$_GET['year']."-".$_GET['month']."-".$_GET['day']."%' AND `users`.`dev`=`health_data`.`dev`AND `users`.`id`=".$_GET['lamp']."  GROUP BY HOUR ( `health_data`.`timestamp` ) ORDER BY `health_data`.`timestamp` ASC;";
$sql="SELECT TIME(`health_data`.`timestamp`) as jam, ROUND( AVG( dia ),0) as dia , ROUND( AVG( sis ),0) as sis, ROUND( AVG( hrr ),0) as hrr, ROUND( AVG( spo ),0) as spo, ROUND( AVG( bat ),0) as bat FROM `users`,`health_data` WHERE `health_data`.`timestamp` LIKE '".$_GET['year']."-".$_GET['month']."-".$_GET['day']."%' AND `users`.`dev`=`health_data`.`dev`AND `users`.`id`=".$_GET['lamp']."  GROUP BY MINUTE ( `health_data`.`timestamp` ) ORDER BY `health_data`.`timestamp` ASC;";
//echo $sql;
$result = $dblink->query($sql);
//$result = $dblink->query("SELECT TIME(waktu) as jam,tegangan,arus,temp FROM ( SELECT * FROM status_lampu WHERE id_lampu=".$_GET['lamp']." ORDER BY waktu DESC LIMIT 20 )Var1 ORDER BY id ASC");

//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);
 
?>