<?php

$sql="TRUNCATE TABLE `status_lampu`";
require_once("../configdb.php");
if ($dblink->query($sql) === TRUE) {
    echo " OK ";
} else {
    echo "Error: " . $sql . "<br>" . $dblink->error;
}
?>