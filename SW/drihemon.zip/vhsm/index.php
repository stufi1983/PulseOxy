<?php

$servername = "localhost";
$database = "stufimedia_db";
$username = "stufimedia_user";
$password = "Percobaan1";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "DB Connected successfully\n";

// Check if the POST request contains data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//{"dev": "FF:AA",  "bat": 99,  "sis": 100,  "dia": 70,  "hrr": 80,  "spo": 96,  "kon": true,  "con": true}

    //print_r($_POST);
	
	// Get the raw POST data
    $json = file_get_contents('php://input');

    // Decode the JSON data into an associative array
    $data = json_decode($json, true);

    // Check if decoding was successful
    if ($data === null) {
        echo "Failed to decode JSON.";
    } else {
        // Extract specific values from the JSON data
        $dev = isset($data['dev']) ? $data['dev'] : '00:00:00:00:00:000';
        $bat = isset($data['bat']) ? $data['bat'] : 0;
        $sis = isset($data['sis']) ? $data['sis'] : 0;
        $dia = isset($data['dia']) ? $data['dia'] : 0;
        $hrr = isset($data['hrr']) ? $data['hrr'] : 0;
        $spo = isset($data['spo']) ? $data['spo'] : 0;
        $kon = isset($data['kon']) ? $data['kon'] : false;
        $con = isset($data['con']) ? $data['con'] : false;
		$sql = "INSERT INTO `health_data` (`id`, `userid`, `timestamp`, `dev`, `bat`, `sis`, `dia`, `hrr`, `spo`, `kon`, `con`) VALUES (NULL, '1', current_timestamp(), '".$dev."', '".$bat."', '".$sis."', '".$dia."', '".$hrr."', '".$spo."', '".$kon."', '".$con."');";
		//echo $sql;
		if ($conn->query($sql) === TRUE) {
		  echo "New record created successfully";
		} else {
		  echo "Error: " . $sql . "<br>" . $conn->error;
		}


		mysqli_close($conn);
		
    }
} else {
    echo "No POST data received.";
}
