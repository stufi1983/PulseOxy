<?php
   ob_start();
   session_start();
   require 'configdb.php'; // Database connection

   if ($_SERVER["REQUEST_METHOD"] == "POST") {
	   $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
	   $password = $_POST['password'];
   
	   // Fetch the user from the database based on the username
	   $sql = "SELECT * FROM users WHERE username = ?";
	   $stmt = $conn->prepare($sql);
	   $stmt->execute([$username]);
   		$user = $stmt->fetch();
   
	   // If user exists and password is verified
	   if ($user && password_verify($password, $user['password'])) {
		   // Set session variables
		   $_SESSION['username'] = $user['username'];
		   $_SESSION['user_role'] = $user['roles'];
		   $_SESSION['userrole'] = $user['roles'];
		   $_SESSION['logged_in'] = true;

		   $_SESSION['valid'] = true;
		   $_SESSION['timeout'] = time();
		   $_SESSION['username'] = $_POST['username'];


		   // Regenerate session ID to prevent session fixation attacks
		   session_regenerate_id(true);
   
		   // Redirect to a protected page or dashboard
		   header("location:index.php?nav=status");
		   exit();
	   } else {
		   // If login fails
		   $msg=urlencode("Username atau Password Salah");
		   $_SESSION['loginerr']=$msg;//.$usernamebenar.$passwordbenar;
		   header("location: index.php");
	}   
}
