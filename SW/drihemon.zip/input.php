<?php 

 
	// echo $tl;

	//koneksi
	include_once("configdb.php");				
	$mysqli = $dblink;

	if(!isset($_GET['id'])) {exit();}
	$id=''; if(isset($_GET['id'])) $id=$_GET['id'];

	if(isset($_GET['cmdid'])){
		if ($result = $mysqli -> query("UPDATE `setting_lampu` SET `status` = 'OK' WHERE `id` = ".$_GET['cmdid']." AND `id_lampu`=".$id.";")) {}
		exit();
	}

	$sql="SELECT id_lampu as id, command as cmd, val, id as cmdid FROM  `setting_lampu` WHERE id_lampu=".$id." AND status='WAIT' ORDER BY waktu ASC LIMIT 1";
	if ($result = $mysqli -> query($sql)) {
		if($result -> num_rows > 0){
			while ( $row = $result->fetch_assoc())  {
				$dbdata[]=$row;
			  }
			  echo json_encode($dbdata,JSON_NUMERIC_CHECK);
			}
		}




	if(!isset($_GET['vl'])) exit();
 	$vl=0; if(isset($_GET['vl'])) $vl=$_GET['vl'];

	// echo $vl;

	if(!isset($_GET['il'])) exit();
 	$il=0; if(isset($_GET['il'])) $il=$_GET['il'];

	// echo $il;

	if(!isset($_GET['tl'])) exit();
 	$tl=0; if(isset($_GET['tl'])) $tl=$_GET['tl'];
	
	if(!is_numeric($vl)||!is_numeric($il)||!is_numeric($tl)) {exit();}
	if($vl==0||$il==0||$tl==0||$il>2) {exit();}
 
	if ($result = $mysqli -> query("
		INSERT INTO `status_lampu` (`id`, `waktu`, `id_lampu`, `tegangan`, `arus`, `temp`) 
			VALUES (NULL, now(), '".$id."', '".$vl."', '".$il."', '".$tl."'); ")) {
	}
	// echo "OK";

 ?>